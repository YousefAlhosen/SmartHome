#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <inttypes.h>
#include <linux/i2c-dev.h> 
#include <sys/ioctl.h>


#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <unistd.h>
#include <time.h>
#include <math.h>
#include <inttypes.h>
#include <assert.h>


#include <linux/gpio.h>
#include <sys/poll.h>

#include "xbee.c"
#include "ads1015.c"
#include "i2c.c"
#include "xbee_receving_process.c"
#include "uart.c"


#include <sys/ioctl.h>
#include <linux/spi/spidev.h>


#define ADC1015_I2C_PORT_PATH   0x48         // Address of our adc converter on the I2C bus
#define I2C_BUS_FD 2

#define SERIAL_PORT_BAUD_RATE 9600
#define XBEE_SERIAL_PORT_PATH  "/dev/ttyUSB1"  //"/dev/ttyUSB0" "/dev/serial0" Address of our Xbee on the UART bus

struct gpioevent_request rq;
struct pollfd pfd;
struct timeval timeout;
fd_set read_fd;
bool packet_received;
int xbee_serial_fd;

int msleep(unsigned int tms) {
  return usleep(tms * 1000);
}
void receive_message_uart(int xbee_serial_fd, fd_set read_fd, uint8_t* rx_buffer);
int main(void) {
    
    printf("Starting the application...\r\n");

    uint8_t tx_buffer[256]; // Buffer to store the bytes that we write to the I2C device
    uint8_t rx_buffer[256];   // byte buffer to store the data read from the I2C device 

    struct gpiohandle_data data;
    int package_length = 13;
    int package_frame_type = 0x00;
    int package_frame_id = 0x00; 
    unsigned char package_address[9] = {0x00,0x13,0xA2,0x00,0x41,0xC7,0x20,0xA0}; //  
    create_xbee_packet(package_length,package_frame_type,package_frame_id,package_address);
    unsigned char tx_xbee_buffer[packet.length+5];

    /* Device-Handle */
    xbee_serial_fd = serial_open(XBEE_SERIAL_PORT_PATH,SERIAL_PORT_BAUD_RATE);
    int adc1015_fd = i2c_open(I2C_BUS_FD,ADC1015_I2C_PORT_PATH);
    init_adc(adc1015_fd,tx_buffer,rx_buffer);

    packet_received = false;
    while (1)
    {   
        ads1015_rx(adc1015_fd,tx_buffer,rx_buffer);
        packet.data[0] = rx_buffer[0];
        packet.data[1] = rx_buffer[1];
        preparing_package(&packet, tx_xbee_buffer);
        write(xbee_serial_fd,tx_xbee_buffer,packet.length+4);
        receive_message_uart(xbee_serial_fd,read_fd,rx_buffer); 

        if(packet_received){
          ads1015_rx(adc1015_fd,tx_buffer,rx_buffer);
          packet.data[0] = rx_buffer[0];
          packet.data[1] = rx_buffer[1];
          preparing_package(&packet, tx_xbee_buffer);
          write(xbee_serial_fd,tx_xbee_buffer,packet.length+4);
        }
    }
    close(adc1015_fd);
    close(xbee_serial_fd);
    return 0;
}

/********************************************
 * receiveMessageUART FUNCTION 
 * Receives and processes received message using UART
 *******************************************/
void receive_message_uart(int xbee_serial_fd, fd_set read_fd, uint8_t* rx_buffer) {
    int retval;
    /* Initialize the timeout */

    timeout.tv_sec  = 10;       //5 Seconds
    timeout.tv_usec = 0;
    FD_ZERO(&read_fd);
    FD_SET(xbee_serial_fd,&read_fd);

    retval = select(xbee_serial_fd+101, &read_fd, NULL, NULL, &timeout);
    if( retval < 0 ) 
    {
            perror("select");
            exit(0);
    }
    printf("Inter");
    if(FD_ISSET(xbee_serial_fd,&read_fd))
    {   
        packet_received = false;
        int buffer_length = read(xbee_serial_fd,rx_buffer,255);;
        for(int buffer_index=0;buffer_index < buffer_length;buffer_index++)
        {
            process(rx_buffer[buffer_index], &packet_received);
        }
    }
}