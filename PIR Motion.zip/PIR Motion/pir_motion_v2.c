#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/gpio.h>
#include <linux/gpio.h>
#include <sys/poll.h>
#include <errno.h>

#include <stdlib.h>
#include <unistd.h>
#include <inttypes.h>
#include <assert.h>

#include "xbee.c"
#include "uart.c"

#define SERIAL_PORT_BAUD_RATE 9600
#define XBEE_SERIAL_PORT_PATH  "/dev/ttyUSB2"  //"/dev/ttyUSB0" "/dev/serial0" Address of our Xbee on the UART bus

struct pollfd pfd;
int xbee_serial_fd;
struct gpioevent_request pir_sensor;
int msleep(unsigned int tms) {
  return usleep(tms * 1000);
}
void setup_gpio_event(void);
int main(){
    uint8_t rx_buffer[256];
    struct gpiohandle_data data;
    int package_length = 37;
    int package_frame_type = 0x00;
    int package_frame_id = 0x00; 
    unsigned char package_address[9] = {0x00,0x13,0xA2,0x00,0x41,0xC7,0x20,0xA0}; //  
    create_xbee_packet(package_length,package_frame_type,package_frame_id,package_address);
    unsigned char title [] = "Somebody is in this area!";
    strcpy(packet.data, title);
    unsigned char tx_buffer[packet.length+5];
   	preparing_package(&packet, tx_buffer);

    xbee_serial_fd = serial_open(XBEE_SERIAL_PORT_PATH,SERIAL_PORT_BAUD_RATE);
    //setup_gpio_event(); 
    while(1){
        setup_gpio_event();
        if (poll(&pfd, 1, -1) == -1)
        {
            printf("Error while polling event from GPIO: %s", strerror(errno));
        }
        
        if (pfd.revents & POLLIN)
        {
            write(xbee_serial_fd,tx_buffer,packet.length+4);
            printf("Somebody is in this area!\n");
            close(pfd.fd);
	        close(pir_sensor.fd);
            //read(pfd.fd,rx_buffer,1);
        } 
    }        
}

void setup_gpio_event(void){
        int fd, ret;
        // open the device
        fd = open("/dev/gpiochip0", O_RDONLY);
        if (fd < 0)
        {
            printf("Unabled to open %s: %s", "/dev/gpiochip0", strerror(errno));
            exit(0);
        }

        pir_sensor.lineoffset = 18;
        pir_sensor.eventflags = GPIOEVENT_REQUEST_RISING_EDGE; 
        ret = ioctl(fd, GPIO_GET_LINEEVENT_IOCTL, &pir_sensor);
        
        if (ret == -1)
        {
            printf("Unable to get line event from ioctl : %s", strerror(errno));
            exit(0);
        }
        pfd.fd = pir_sensor.fd;
        pfd.events = POLLIN;
}
