
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>


struct xBeePacket{
    unsigned int length;
    unsigned char frame_type;
    unsigned char frame_id;
    unsigned char dest_address[9];
    unsigned char options;
    unsigned char data[255];  // Length 
}packet;


void create_xbee_packet(unsigned char length, unsigned char frame_type, unsigned char frame_id, unsigned char *address){
    packet.length = length;
    packet.frame_type = frame_type;
    packet.frame_id = frame_id;
    //packet.options = 0;
    for (int i = 0; i < 8; i++)
    {
        packet.dest_address[i] = (unsigned char) address[i];
    }
}


void preparing_package(struct xBeePacket* p, unsigned char *tx_buff){
    
    unsigned char checksum = 0;

    tx_buff[0]=0x7E;			// send start bit
    tx_buff[1]= (unsigned char)(p->length>>8); // send the most significant byte (MSB).
    tx_buff[2]= (unsigned char)(p->length & 0x00FF); // send the least significant byte (LSB)

    tx_buff[3]=(p->frame_type);
    checksum += p->frame_type;	// add frame type to checksum
    tx_buff[4]=(p->frame_id);
    checksum += p->frame_id; // add frame ID to checksum

    /* the mac address is now sent, 6 byte */
    for (int i = 5; i < 13; i++)
    {
        tx_buff[i]= (unsigned char) (p->dest_address[i-5]);
        checksum += p->dest_address[i-5]; //add to checksum
    }

    tx_buff[13] = (p->options);
    checksum += p->options;

    /* The actual message/data is set */

    int tx_index = 14;
    for(int i = 0;i<p->length-11; i++){
        tx_buff[tx_index]= p->data[i];
        checksum += p->data[i];
        tx_index +=1;
    }

    /* calculate the proper checksum */
    tx_buff[tx_index] = (0xFF-checksum);

}
