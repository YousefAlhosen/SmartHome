
#include <string.h>  
#include <stdio.h>  
#include <errno.h>  
#include <unistd.h>  
#include <fcntl.h>  
#include <sys/ioctl.h>  
#include <gpiod.h>  
#include <sys/epoll.h>  
#include <pthread.h>

#include "xbee.c"

typedef void (*eventHandler)(struct gpiod_line_event *);  

typedef struct  {  struct gpiod_line *line;  eventHandler func;  } intVec, intVec_2;  

void LED_handler(struct gpiod_line_event *event){

   //printf("%d,%d \n\r", event->event_type,  event->ts.tv_nsec/ 1000);  fflush(stdout); 
    unsigned char title [] = "LED";
    strcpy(packet.data, title);
    uint8_t tx_buffer[packet.length+5];
   	preparing_package(&packet, tx_buffer);
    printf("Interupt\n"); 
} 

void temp_Handler(struct gpiod_line_event *event){

  // printf("%d,%d \n\r", event->event_type,  event->ts.tv_nsec/ 1000);  fflush(stdout); 
   printf("KING Interupt 2 !!!!\n"); 
} 

intVec interupt_LED, temp_interupt;

void led_button();
void temp_button();
void *wait_Interrupt_LED(void *arg);
void *wait_Interrupt_2(void *arg);

int main (void) 
{  
    int package_length = 14;
    int package_frame_type = 0x00;
    int package_frame_id = 0x00; 
    unsigned char package_address[9] = {0x00,0x13,0xA2,0x00,0x41,0xC7,0x20,0x8A}; //  0x00,0x13,0xA2,0x00,0x41,0xC7,0x20,0x87 
    create_xbee_packet(package_length,package_frame_type,package_frame_id,package_address);
    led_button();
    temp_button();
    for (;;) {  
        printf("Working\n\r");  
        fflush(stdout);  
        sleep(2);  
    }  
} 
  
void led_button(){
    struct gpiod_chip *chip = gpiod_chip_open_by_number(0); 
    struct gpiod_line *line12 = gpiod_chip_get_line(chip, 12);  
    int res = gpiod_line_request_falling_edge_events(line12, "button");  

    interupt_LED.line = line12;  
    interupt_LED.func = &LED_handler;  

    pthread_t intThread;  
    if (pthread_create(&intThread, NULL, wait_Interrupt_LED,  (void *)&interupt_LED)) 
    {  
        fprintf(stderr, "Error creating thread\n");  
        exit(0);  
    }    
}

void temp_button(){
    struct gpiod_chip *chip2 = gpiod_chip_open_by_number(0); 
    struct gpiod_line *line6 = gpiod_chip_get_line(chip2, 6);  
    int res = gpiod_line_request_falling_edge_events(line6, "button nr 2");  
    temp_interupt.line = line6;  
    temp_interupt.func = &temp_Handler;

    pthread_t intThread_2;  
    if (pthread_create(&intThread_2, NULL, wait_Interrupt_2,  (void *)&temp_interupt)) 
    {  
        fprintf(stderr, "Error creating thread\n");  
        exit(0);  
    }
}
void *wait_Interrupt_LED(void *arg){  
    intVec *intData = (intVec *)arg;  
    struct gpiod_line_event event;  
    while (true)
    {  
        int res = gpiod_line_event_read(intData->line, &event);  
        if (res == 0)  intData->func(&event);  
    }  
} 

void *wait_Interrupt_2(void *arg){  
    intVec *intData = (intVec *)arg;  
    struct gpiod_line_event event;  
    while (true)
    {  
        int res = gpiod_line_event_read(intData->line, &event);  
        if (res == 0)  intData->func(&event);  
    }  
}