
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <inttypes.h>
#include <linux/i2c-dev.h> 
#include <sys/ioctl.h>

#include <string.h>
#include <stdint.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <unistd.h>
#include <time.h>
#include <math.h>
#include <inttypes.h>
#include <assert.h>
#include <stdbool.h>
#include <sys/time.h>

char TimeString[128];

void get_current_time(){
    static int seconds_last = 99;
    struct timeval curTime;
	gettimeofday(&curTime, NULL);
	if (seconds_last == curTime.tv_sec)
		return;
	
	seconds_last = curTime.tv_sec;
	
	strftime(TimeString, 80, "%Y-%m-%d %H:%M:%S", localtime(&curTime.tv_sec));
}

/* Save the list */
void save_led_status(int led_status){
    FILE *fp;
    if((fp=fopen("LED Status","a+"))==NULL){
        printf("Cannot open file.\n");
    }
    /* Write to file */
    if(led_status%2 == 0){
        fprintf(fp,"%s LED was OFF\n",TimeString);
    }
    if(led_status%2 == 1){
        fprintf(fp,"%s LED was ON\n",TimeString);
    }
    fclose(fp);
}

void save_motion_status(unsigned char *rx_buffer){
    get_current_time();
    int start = 3;
    int len = rx_buffer[2];
    //printf("%.*s\n", len, rx_buffer + start);
    FILE *fp;

    if((fp=fopen("PIR Motion","a+"))==NULL){
        printf("Cannot open file.\n");
    }
    /* Write to file */
    fprintf(fp,"%s %.*s\n",TimeString, len, rx_buffer + start);
    fclose(fp);    
}
void save_temp(float temperature){
    get_current_time();
    FILE *fp;

    if((fp=fopen("TEMP","a+"))==NULL){
        printf("Cannot open file.\n");
    }
    /* Write temperature to file */
    fprintf(fp,"%s Temperature: %.1f \xC2\xB0",TimeString, temperature);
    fprintf(fp,"C\n");
    fclose(fp);

}

