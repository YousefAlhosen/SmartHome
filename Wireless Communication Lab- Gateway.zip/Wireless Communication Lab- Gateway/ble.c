#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <bluetooth/bluetooth.h>
#include <bluetooth/l2cap.h>
#include <errno.h>

#include <syscall.h>  
#include <sched.h>


#include <bluetooth/hci.h>
#include <bluetooth/hci_lib.h>

#include <time.h>

#include <sys/epoll.h> 
#include <linux/gpio.h>
#include <inttypes.h>
#include <assert.h>
#include <unistd.h>
#include <stdbool.h>

static struct epoll_event ev;
struct gpioevent_request receiving_puls_gpio_rq;
#include <stdlib.h>

//global vars
int received_package = 0;
int wrong_package = 0;


fd_set read_fd;
struct timeval timeout; 
char btReadBuf[256] = { 0 };
int sock_fd, client;
float temperature;
#include <string.h>  
#include <stdio.h>  
#include <errno.h>  
#include <unistd.h>  
#include <fcntl.h>  
#include <sys/ioctl.h>  
#include <gpiod.h>  
#include <sys/epoll.h>  
#include <pthread.h>

#include "xbee.c"
#include "file.c"

typedef void (*eventHandler)(struct gpiod_line_event *);  

typedef struct  {  struct gpiod_line *line;  eventHandler func;  } intVec, intVec_2;  
int led_status = 1;
void LED_handler(struct gpiod_line_event *event){
    int package_length = 14;
    int package_frame_type = 0x00;
    int package_frame_id = 0x00; 
    unsigned char package_address[9] = {0x00,0x13,0xA2,0x00,0x41,0xC7,0x20,0x87}; //  0013A20041C72112
    create_xbee_packet(package_length,package_frame_type,package_frame_id,package_address);
   //printf("%d,%d \n\r", event->event_type,  event->ts.tv_nsec/ 1000);  fflush(stdout); 
    unsigned char title [] = "LED";
    strcpy(packet.data, title);
    unsigned char tx_buffer[packet.length+5];
   	preparing_package(&packet, tx_buffer);
    printf("Interupt LED\n"); 
        //send read value across bluetooth:
    if(write(client, tx_buffer , packet.length+4) == packet.length+4){
        /*
        printf("Sending %X\n", tx_buffer);
        for(int i=0;i<packet.length+4;i++){
            //printf("%X\n", tx_buffer[i]);
        }
        */
       save_led_status(led_status);
       led_status ++;
    }
} 

void temp_Handler(struct gpiod_line_event *event){

  // printf("%d,%d \n\r", event->event_type,  event->ts.tv_nsec/ 1000);  fflush(stdout); 0013A20041C72087
    int package_length = 24;
    int package_frame_type = 0x00;
    int package_frame_id = 0x00; 
    unsigned char package_address[9] = {0x00,0x13,0xA2,0x00,0x41,0xC7,0x21,0x12}; //  
    create_xbee_packet(package_length,package_frame_type,package_frame_id,package_address);
    unsigned char title [] = "TEMP Request!";
    strcpy(packet.data, title);
    unsigned char tx_buffer[packet.length+5];
   	preparing_package(&packet, tx_buffer);
    printf("Interupt TEMP\n"); 
    //send read value across bluetooth:
    /*
    if(write(client, tx_buffer , packet.length+4) == packet.length+4){
        printf("Sending %X\n", tx_buffer);
    }
    */
    if(write(client, tx_buffer , packet.length+4) == packet.length+4){
        save_temp(temperature);
    }
} 

intVec interupt_LED, temp_interupt;
unsigned char rx_buffer[256];  
void led_button();
void temp_button();
void *wait_Interrupt_LED(void *arg);
void *wait_Interrupt_2(void *arg);
void pir_motion_sensor();
void temp_sensor();
int msleep(unsigned int tms) {
  return usleep(tms * 1000);
}
int main(int argc, char **argv) 
{

    //setDiscoverableOnCli();
    if (system("bluetoothctl discoverable on") < 0) {
        perror("Could not turn discoverable on");
    }

    int count = 0;
    int numWritten;
    float volts;
    int pwmVal;

    struct sockaddr_l2 loc_addr = { 0 }, rem_addr = { 0 };
    //char btReadBuf[1024] = { 0 };
    int bytes_read;
    socklen_t opt = sizeof(rem_addr);

    // allocate socket
    sock_fd = socket(AF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_L2CAP);

    // bind socket to port 0x1001 of the first available 
    // bluetooth adapter
    loc_addr.l2_family = AF_BLUETOOTH;
    loc_addr.l2_bdaddr = *BDADDR_ANY;
    loc_addr.l2_psm = htobs(0x1001);
    bind(sock_fd, (struct sockaddr *)&loc_addr, sizeof(loc_addr));

    // put socket into listening mode
    listen(sock_fd, 1);

    // accept one connection
    client = accept(sock_fd, (struct sockaddr *)&rem_addr, &opt);
    printf("client: %d\n", client);

    ba2str( &rem_addr.l2_bdaddr, btReadBuf );
    fprintf(stderr, "accepted connection from %s\n", btReadBuf);
    memset(btReadBuf, 0, sizeof(btReadBuf));
    
    int package_length = 14;
    int package_frame_type = 0x00;
    int package_frame_id = 0x00; 
    unsigned char package_address[9] = {0x00,0x13,0xA2,0x00,0x41,0xC7,0x21,0x12}; //  0013A20041C72112
    create_xbee_packet(package_length,package_frame_type,package_frame_id,package_address);
    led_button();
    temp_button();
    for (;;) {  
       /* Initialize the file descriptor set. */
        FD_ZERO(&read_fd );
        FD_SET(client, &read_fd);
            
        /* Initialize the timeout */

        timeout.tv_sec  = 2;       //2 Seconds
        timeout.tv_usec = 0;
        int retval = select(client+100, &read_fd, NULL, NULL, &timeout); //&timeout
            
        if( retval < 0 ) 
        {
            perror("select");
            assert(0);
        }
        
        if(FD_ISSET(client, &read_fd))
        {
            int buffer_length = read(client, &rx_buffer, sizeof(rx_buffer));
            if(buffer_length > 3){
                /*
                printf("Recived data in select func: \n");
                
                for(int i=0;i<rx_buffer[2];i++){
                    printf("%X\n", rx_buffer[i]);
                }
                */
                if(rx_buffer[1] == 1){
                    temp_sensor();
                    save_temp(temperature);
                }
                if(rx_buffer[1] == 3){
                    pir_motion_sensor();
                    save_motion_status(rx_buffer);
                }
            }
        }

        //printf("Working\n\r");  
        fflush(stdout);  
    }

    // close connection
    close(client);
    close(sock_fd);
}


/********************************************
 * runSelectFunc FUNCTION 
 * 
 *******************************************/
 void runSelectFunc() {
    bool read_data = true;   
    while(read_data){   
        /* Initialize the file descriptor set. */
        FD_ZERO(&read_fd );
        FD_SET(client, &read_fd);
            
        /* Initialize the timeout */

        timeout.tv_sec  = 2;       //2 Seconds
        timeout.tv_usec = 0;
        int retval = select(client+100, &read_fd, NULL, NULL, &timeout); //&timeout
            
        if( retval < 0 ) 
        {
            perror("select");
            assert(0);
        }else if(retval == 0)
        {
            printf("No data is waiting\n");
        }
        
        if(FD_ISSET(client, &read_fd))
        {
            int buffer_length = read(client, &btReadBuf, 2);
            if(buffer_length == 2){
                //printf("Recived data in select func: %d\n",btReadBuf);
                read_data = false;
            }
            if (buffer_length==0) {
                
            }
        }
    }
 }


  
void led_button(){
    struct gpiod_chip *chip = gpiod_chip_open_by_number(0); 
    struct gpiod_line *line12 = gpiod_chip_get_line(chip, 12);  
    int res = gpiod_line_request_falling_edge_events(line12, "button");  

    interupt_LED.line = line12;  
    interupt_LED.func = &LED_handler;  

    pthread_t intThread;  
    if (pthread_create(&intThread, NULL, wait_Interrupt_LED,  (void *)&interupt_LED)) 
    {  
        fprintf(stderr, "Error creating thread\n");  
        exit(0);  
    }    
}

void temp_button(){
    struct gpiod_chip *chip2 = gpiod_chip_open_by_number(0); 
    struct gpiod_line *line6 = gpiod_chip_get_line(chip2, 6);  
    int res = gpiod_line_request_falling_edge_events(line6, "button nr 2");  
    temp_interupt.line = line6;  
    temp_interupt.func = &temp_Handler;

    pthread_t intThread_2;  
    if (pthread_create(&intThread_2, NULL, wait_Interrupt_2,  (void *)&temp_interupt)) 
    {  
        fprintf(stderr, "Error creating thread\n");  
        exit(0);  
    }
}
void *wait_Interrupt_LED(void *arg){  
    intVec *intData = (intVec *)arg;  
    struct gpiod_line_event event;  
    while (true)
    {  
        int res = gpiod_line_event_read(intData->line, &event);  
        if (res == 0)  intData->func(&event);  
    }  
} 

void *wait_Interrupt_2(void *arg){  
    intVec *intData = (intVec *)arg;  
    struct gpiod_line_event event;  
    while (true)
    {  
        int res = gpiod_line_event_read(intData->line, &event);  
        if (res == 0)  intData->func(&event);  
    }  
}

void pir_motion_sensor(){
  int start = 3;
  int len = rx_buffer[2];
  printf("%.*s\n", len, rx_buffer + start);
}

void temp_sensor(){

  /* Combine the two bytes of readBuf into a single 16 bit result to 
            Get the voltage reading from the LM35 */
    int16_t adc_val = rx_buffer[3] << 8 | rx_buffer[4];	

    // Convert that reading into voltage
    float voltage = (float) adc_val*6.144/32767.0;

    // Convert the voltage into the temperature in Celsius
    temperature = voltage * 100;

    // Print the temperature in Celsius
    printf("Temperature: %.1f \xC2\xB0", temperature);	
    printf("C\n");

}