#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <bluetooth/bluetooth.h>
#include <bluetooth/l2cap.h>
//---hci commands and events
#include <bluetooth/hci.h>
#include <bluetooth/hci_lib.h>
//------

#include <linux/gpio.h>
#include <sys/poll.h>

#include <syscall.h>  
#include <sched.h>
#include <stdbool.h>
//Stopwatch: 
#include <time.h>
#include <errno.h>
#include <assert.h>

#include "uart.c"
#include "xbee_process.c"

#define SERIAL_PORT_BAUD_RATE 9600

#define XBEE_SERIAL_PORT_PATH  "/dev/ttyUSB0"  //"/dev/ttyUSB0" "/dev/serial0" Address of our Xbee on the UART bus

int s, status;
bool run_program,packet_received;
fd_set write_fd, read_fd;
struct timeval timeout;
uint8_t tx_buffer[256]; // Buffer to store the bytes that we write to the I2C device
uint8_t rx_buffer[256];   // byte buffer to store the data read from the I2C device 

int xbee_serial_fd;
struct gpiohandle_request signal;

//prototypes
int delay_ms(unsigned int tms);

int msleep(unsigned int tms) {
  return usleep(tms * 1000);
}

void time_handler1(size_t timer_id, void * user_data)
{
    //run_program = false;
}
//Global vars
int i = 0;
void runSelectFunc();
/********************************************
 * MAIN FUNCTION 
 *******************************************/
int main(int argc, char **argv)
{
    //adc_fd = i2c_open(i2c_port, ads_addr);
    //init_adc(adc_fd, adcWriteBuf, adcReadBuf);
    
    struct sockaddr_l2 addr = { 0 };

    char dest[18] = "B8:27:EB:EE:46:E3"; //"C8:94:02:6D:D5:84" <-laptop; //B8:27:EB:EE:46:E3 <-curaspi, jacob -> 50:76:AF:5C:D7:A2

    // allocate a socket
    s = socket(AF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_L2CAP);

    // set the connection parameters (who to connect to)
    addr.l2_family = AF_BLUETOOTH;
    addr.l2_psm = htobs(0x1001);    //kind of port number.
    str2ba( dest, &addr.l2_bdaddr );

    // connect to server
    status = connect(s, (struct sockaddr *)&addr, sizeof(addr));
    if( status < 0 ) {
        printf("%d %s\n", errno, strerror(errno));
        printf("No connection :(\n");
        close(s);
    } 
    else {
            
            xbee_serial_fd;
            xbee_serial_fd = serial_open(XBEE_SERIAL_PORT_PATH,SERIAL_PORT_BAUD_RATE);
            struct timespec time;
            int nbr_of_tests = 0;
            run_program = true;
            while (1)
            {      
                runSelectFunc();     
            }
        }
    //printf("Antalet Skickade BLE Packet: %d\n",i);
    close(s);
    
    #if 0
    //ADC TEST:
    changemode(1);
        while (!kbhit()) { 
            read_adc(adc_fd, adcWriteBuf, adcReadBuf); 
            delay_ms(100);
        }
    changemode(0);
    #endif
}

/********************************************
 * delay_ms FUNCTION 
 * Produces a delay of tms milliseconds
 *******************************************/
int delay_ms(unsigned int tms) {
  return usleep(tms * 1000);
}

void runSelectFunc() {
    bool send_data = true; 
    packet_received = false;  
    while(send_data){   
        #if 1 
        /* Initialize the file descriptor set. */
        FD_ZERO(&write_fd);
        FD_SET(s, &write_fd);
        
        FD_ZERO(&read_fd );
        FD_SET(s,&read_fd);
        FD_SET(xbee_serial_fd,&read_fd);

        /* Initialize the timeout */

        timeout.tv_sec  = 2;       //2 Seconds
        timeout.tv_usec = 0;
        int retval = select(s+xbee_serial_fd+100,&read_fd, &write_fd, NULL, &timeout); //&timeout
            
        if( retval < 0 ) 
        {
            perror("select");
            assert(0);
        }else if(retval == 0)
        {
            printf("No data is waiting\n");
        }
        
        if(FD_ISSET(s, &read_fd))
        {
            int buffer_length = read(s, &tx_buffer, sizeof(tx_buffer));
            if(buffer_length > 10){
                write(xbee_serial_fd,tx_buffer,sizeof(tx_buffer));
                printf("Recived data in select func: %x\n",tx_buffer);
                for(int i=0;i<18;i++){
                    printf("%X\n", tx_buffer[i]);
                }
            }
        }
        if(FD_ISSET(xbee_serial_fd, &read_fd))
        {
            int buffer_length = read(xbee_serial_fd,&rx_buffer, 1);
            while (buffer_length > 0)
            {
                for(int buffer_index=0;buffer_index < buffer_length;buffer_index++)
                {
                    process(rx_buffer[buffer_index],&packet_received);
                }
                buffer_length = read(xbee_serial_fd,&rx_buffer, 1);
            }
        }

        if(packet_received){ 
            preparing_package(&package,tx_buffer);
            int j = write(s,tx_buffer,tx_buffer[2]+3);
            printf("Antalet sända byte är %d byte",j);
            for(int i=0;i<tx_buffer[2]+3;i++){
                printf("%X\n", tx_buffer[i]);
            }
            packet_received = false;
        }
        #else
            int buffer_length = read(client, &btReadBuf, 2);
            if(buffer_length == 2){
                //printf("Recived data: %s\n",btReadBuf);
                read_data = false;
            }
        #endif
    }
 }