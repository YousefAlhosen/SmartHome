#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/gpio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h> 

#include "uart.c"
#include "xbee_process.c"

#define SERIAL_PORT_BAUD_RATE 9600
#define XBEE_SERIAL_PORT_PATH  "/dev/ttyUSB0"  //"/dev/ttyUSB0" "/dev/serial0" Address of our Xbee on the UART bus

int xbee_serial_fd;
bool packet_received;

void receive_message_uart(int xbee_serial_fd, fd_set read_fd, uint8_t* rx_buffer);
int main() {
	int fd;
    uint8_t rx_buffer[255];   // byte buffer to store the data read from the I2C device 
	struct gpiohandle_request led;
	struct gpiohandle_data data;

    xbee_serial_fd = serial_open(XBEE_SERIAL_PORT_PATH,SERIAL_PORT_BAUD_RATE);
    fd_set read_fd;
    FD_ZERO(&read_fd);
    FD_SET(xbee_serial_fd,&read_fd);

    packet_received = false;

	/* Open the gpiochip device file */
	fd = open("/dev/gpiochip0", O_RDWR);
	if(fd < 0) {
		perror("Error opening gpiochip0");
		return -1;
	}

	/* Setup LED to output */
	led.flags = GPIOHANDLE_REQUEST_OUTPUT;
	strcpy(led.consumer_label, "LED");
	memset(led.default_values, 0, sizeof(led.default_values));
	led.lines = 1;
	led.lineoffsets[0] = 20;
    led.default_values[0] = 0;

	if(ioctl(fd, GPIO_GET_LINEHANDLE_IOCTL, &led) < 0) {
		perror("Error setting GPIO 16 to output");
		close(fd);
		return -1;
	}
    int count = 1;
    while(1){
        receive_message_uart(xbee_serial_fd,read_fd,rx_buffer);      
        if(packet_received){ 
            packet_received = false;
            if(count%2==1){
                /* Set the LED */
                data.values[0] = 1;
                if(ioctl(led.fd, GPIOHANDLE_SET_LINE_VALUES_IOCTL, &data) < 0) 
                    perror("Error setting GPIO to 1");
                printf("LED is ON\n");
            }else{
                /* Turn off the LED */
                data.values[0] = 0;
                if(ioctl(led.fd, GPIOHANDLE_SET_LINE_VALUES_IOCTL, &data) < 0) 
                    perror("Error setting GPIO to 1");
                printf("LED is OFF\n");                
            }
            count++;
        }  
    }

	close(fd);
	close(led.fd);

	return 0;
}

/********************************************
 * receiveMessageUART FUNCTION 
 * Receives and processes received message using UART
 *******************************************/
void receive_message_uart(int xbee_serial_fd, fd_set read_fd, uint8_t* rx_buffer) {
    int retval;
    bool received = false;
    while(!packet_received){
        FD_ZERO(&read_fd);
        FD_SET(xbee_serial_fd,&read_fd);

        retval = select(xbee_serial_fd+101, &read_fd, NULL, NULL, NULL);
        if( retval < 0 ) 
        {
                perror("select");
                exit(0);
        }

        if(FD_ISSET(xbee_serial_fd,&read_fd))
        {
            int buffer_length = read(xbee_serial_fd,rx_buffer,255);;
            for(int buffer_index=0;buffer_index < buffer_length;buffer_index++)
            {
                process(rx_buffer[buffer_index], &packet_received);
            }
        }
    }    
}